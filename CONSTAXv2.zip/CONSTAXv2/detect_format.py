import sys, os, unicodedata, argparse, glob

parser = argparse.ArgumentParser()
parser.add_argument("-d", "--db", type=str, help="database file")
parser.add_argument("-t", "--tf", type=str, help="training files path")
args = parser.parse_args()

silva = "null"
filename = args.db

## Check if file exists
try:
	open(filename,"r")
except IOError:
	valid = 0
	sys.exit()


with open(filename,"r") as input_file:
	line = input_file.readline()
	line_bar_split = line.split("|")
	if line[0]!=">": # or len(temp0)!= 5:
		sys.exit()
	elif len(line_bar_split) > 1: # UNITE, because "|" is used in accessio
		if "k__" in line_bar_split[-1]: # kingdom header is defined
			format="UNITE"

	elif line.count(";") >= 1: # Silva has ranks divided by ";"
		format = "SILVA"
print(format)
